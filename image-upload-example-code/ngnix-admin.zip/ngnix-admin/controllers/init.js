var fs = require('fs');

// This method introspects the current folder (controllers)
// and iterates through each where the name ends with "controller"
// then loads the controller module

module.exports = function(app, services) {
  fs.readdir(__dirname, function(err, files) {
    if (err) {
      throw err;
    }
    files.forEach(function(file) {
      var name = file.replace('.js', '');
      if(/controller$/.test(name)){
          require('./' + name)(app, services);
      }
    });
  });
};
