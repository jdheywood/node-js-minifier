var fs = require('fs')
, config = require('../config');

module.exports = function(app, services) {
	app.get('/', function(req, res){
		var response = { title: 'Express' };
		res.render('index.html', response);
	});
	
	app.get('/form', function(req, res) {
		// a simple example of a service with a callback
		// the nature of node's execution async model means that a lot of services (mongo, filesystem calls etc) use callbacks
		// so one you can get your head around it, you're golden
		
		services.myService.multiply(Math.floor((Math.random() * 100) + 1), function(result) {
			res.render('form.html', {multiplied_value: result});
		});
	});
	
	app.post('/form', function(req, res) {
		// post data is held within the req.body variable
		// res.json just returns a json object rather than rendering an html page via a view engine
		res.json(req.body);
	});
};