/**
 * Module dependencies.
 */

var express = require('express')
  , http = require('http')
  , path = require('path')
  , swig = require('swig') // view engine
  , config = require('./config'); // config.js in the root, handy for config settings such as DB connection strings

var app = express();

// APP SETUP, View Engine, Port etc
app.set('port', process.env.PORT || 3000);
app.engine('html', swig.renderFile);
app.set('view engine', 'html');
app.set('views', __dirname + '/views');

app.set('view cache', false);
swig.setDefaults({ cache: false });

// HTTP Middleware/Handers
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(express.cookieParser('your secret here'));
app.use(express.session());

app.use(app.router);
app.use(require('less-middleware')({ src: __dirname + '/public' }));
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}


http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});

var myService = {
	multiply: function(number, callback) {
		callback(number * number);
	}
}

// Rather than defining ALL of the routes here, we can hand this off into the method below
// We pass both the Express App obj as well as an object of servicices so that the controllers have access to them.
require('./controllers/init')(app, {myService: myService});