module.exports = {
	nginxConfig: '/usr/local/conf/nginx.conf',
	mongoDBConnString: 'mongodb://localhost:27017/db_name'
};